from django.shortcuts import render, get_object_or_404, redirect
from .models import Product, CartItem, Order, Category
from .forms import AddToCartForm, CheckoutForm
from django.contrib.auth.decorators import login_required
def index(request):
    category_id = request.GET.get('category')
    products = Product.objects.all()
    if category_id:
        products = products.filter(category_id=category_id)
    categories = Category.objects.all()
    return render(request, 'marketplace/index.html', {'products': products,'categories': categories,'selected_category': int(category_id) if category_id else None})
def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    form = AddToCartForm(request.POST or None)
    return render(request, 'marketplace/product_detail.html', {'product': product, 'form': form})
@login_required
def add_to_cart(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = AddToCartForm(request.POST)
        if form.is_valid():
            qty = form.cleaned_data['quantity']
            cart_item, created = CartItem.objects.get_or_create(user=request.user, product=product)
            if not created:
                cart_item.quantity += qty
            else:
                cart_item.quantity = qty
            cart_item.save()
    return redirect('marketplace:cart')
@login_required
def cart_view(request):
    items = CartItem.objects.filter(user=request.user)
    total = sum([it.subtotal() for it in items])
    return render(request, 'marketplace/cart.html', {'items': items, 'total': total})
@login_required
def checkout(request):
    items = CartItem.objects.filter(user=request.user)
    if not items.exists():
        return redirect('marketplace:index')
    if request.method == 'POST':
        form = CheckoutForm(request.POST)
        if form.is_valid():
            total = sum([it.subtotal() for it in items])
            order = Order.objects.create(user=request.user, total_price=total, status='paid')
            items.delete()
            return redirect('marketplace:checkout_success', pk=order.pk)
    else:
        form = CheckoutForm()
    total = sum([it.subtotal() for it in items])
    return render(request, 'marketplace/checkout.html', {'items': items, 'total': total, 'form': form})
@login_required
def checkout_success(request, pk):
    order = get_object_or_404(Order, pk=pk, user=request.user)
    return render(request, 'marketplace/checkout_success.html', {'order': order})
