from django.urls import path
from . import views

app_name = 'tickets'

urlpatterns = [
    path('', views.index, name='index'),
    path('search/', views.search_results, name='search'),
    path('ticket/<int:pk>/', views.ticket_detail, name='ticket_detail'),
    path('booking/<int:pk>/', views.booking_view, name='booking'),  
    path('booking/success/<int:pk>/', views.booking_success, name='booking_success'),
]
