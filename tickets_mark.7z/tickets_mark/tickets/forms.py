from django import forms
from .models import Booking
class SearchForm(forms.Form):
    transport_type = forms.ChoiceField(choices=[('','Любой'),('plane','Самолёт'),('train','Поезд')], required=False)
    origin = forms.CharField(required=False)
    destination = forms.CharField(required=False)
    date = forms.DateField(required=False, widget=forms.DateInput(attrs={'type':'date'}))
class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['seats']
