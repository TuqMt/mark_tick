from django.contrib import admin
from .models import Route, Booking
@admin.register(Route)
class RouteAdmin(admin.ModelAdmin):
    list_display = ('origin','destination','transport_type','departure_time','price','seats_available')
@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('id','user','route','seats','is_paid','booked_at')
