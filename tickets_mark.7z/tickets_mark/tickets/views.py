from django.shortcuts import render, get_object_or_404, redirect
from .models import Route, Booking
from .forms import SearchForm, BookingForm
from django.contrib.auth.decorators import login_required
def index(request):
    form = SearchForm(request.GET or None)
    routes = Route.objects.all().order_by('departure_time')[:10]
    return render(request, 'tickets/index.html', {'form': form, 'routes': routes})
def search_results(request):
    form = SearchForm(request.GET or None)
    qs = Route.objects.all()
    if form.is_valid():
        data = form.cleaned_data
        if data.get('transport_type'):
            qs = qs.filter(transport_type=data['transport_type'])
        if data.get('origin'):
            qs = qs.filter(origin__icontains=data['origin'])
        if data.get('destination'):
            qs = qs.filter(destination__icontains=data['destination'])
        if data.get('date'):
            qs = qs.filter(departure_time__date=data['date'])
    return render(request, 'tickets/search_results.html', {'routes': qs, 'form': form})
def ticket_detail(request, pk):
    route = get_object_or_404(Route, pk=pk)
    return render(request, 'tickets/ticket_detail.html', {'route': route})
@login_required
def booking_view(request, pk):
    route = get_object_or_404(Route, pk=pk)
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.user = request.user
            booking.route = route
            if booking.seats > route.seats_available:
                form.add_error('seats', 'Недостаточно мест')
            else:
                booking.save()
                route.seats_available -= booking.seats
                route.save()
                return redirect('tickets:booking_success', pk=booking.pk)
    else:
        form = BookingForm()
    return render(request, 'tickets/booking.html', {'form': form, 'route': route})
@login_required
def booking_success(request, pk):
    booking = get_object_or_404(Booking, pk=pk, user=request.user)
    booking.is_paid = True
    booking.save()
    return render(request, 'tickets/booking_success.html', {'booking': booking})


from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login

def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('/')
    else:
        form = UserCreationForm()
    return render(request, 'accounts/register.html', {'form': form})
